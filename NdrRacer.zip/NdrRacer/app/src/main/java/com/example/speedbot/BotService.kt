package com.example.speedbot

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

class BotService : Service() {
    companion object {
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val injector = Injector()

    private var realW = 0; private var realH = 0
    private var sw = 180; private var sh = 400
    private lateinit var buf: IntArray

    private var lastTap = 0L; private var lastFrame = 0L; private var lastStart = 0L
    private var lastLog = 0L
    private var autoRestart = false
    private var lastCarX = -1f

    // تتبع السرعة والمسار المتوقع بين النقر واكتمال حركة السيارة (~0.2ث)
    private var speed = 0.17f
    private val prevHaz = FloatArray(3) { -1f }
    private var prevT = 0L
    private var expLane = -1; private var settleUntil = 0L

    override fun attachBaseContext(base: Context) { super.attachBaseContext(Lang.wrap(base)) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        autoRestart = intent?.getBooleanExtra("auto", false) ?: false
        startForegroundNotif()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data") ?: run { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, null)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        realW = dm.widthPixels; realH = dm.heightPixels
        sh = sw * realH / realW
        buf = IntArray(sw * sh)

        thread = HandlerThread("bot").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(realW, realH, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay("bot", realW, realH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastFrame < 25) return@setOnImageAvailableListener
                lastFrame = now
                val plane = img.planes[0]; val bb = plane.buffer
                val rs = plane.rowStride; val ps = plane.pixelStride
                for (y in 0 until sh) {
                    val sy = y * realH / sh
                    for (x in 0 until sw) {
                        val o = sy * rs + (x * realW / sw) * ps
                        buf[y * sw + x] = (bb.get(o).toInt() and 255 shl 16) or
                            (bb.get(o + 1).toInt() and 255 shl 8) or (bb.get(o + 2).toInt() and 255)
                    }
                }
                step(now)
            } finally { img.close() }
        }, handler)
        running = true
        return START_NOT_STICKY
    }

    private fun tapFrac(fx: Float, fy: Float) = injector.tap((fx * realW).toInt(), (fy * realH).toInt())

    private fun laneCenterX(l: Int) = Vision.ROAD_L + (Vision.ROAD_R - Vision.ROAD_L) * (l + 0.5f) / 3f

    private fun step(now: Long) {
        val settling = now < settleUntil && expLane >= 0
        val hint = if (settling) laneCenterX(expLane) else lastCarX
        val r = Vision.analyze(buf, sw, sh, hint)
        if (now - lastLog > 1000) { lastLog = now
            Log.d("Bot", "racing=${r.racing} car=${r.car} haz=${r.haz.toList()} fuel=${r.fuel.toList()} speed=$speed menu=${r.menu}") }
        if (!r.racing) {   // menu / results screen
            lastCarX = -1f
            if (r.menu && autoRestart && now - lastStart > 3000) { lastStart = now; tapFrac(0.49f, 0.80f) }
            return
        }
        if (r.car >= 0) lastCarX = r.carX
        updateSpeed(r, now)
        val car = if (settling) expLane else r.car
        if (car < 0) return
        if (now - lastTap < 70) return
        val dir = Planner.decide(r, car, speed)
        if (dir != 0) {
            lastTap = now
            tapFrac(if (dir < 0) 0.159f else 0.839f, 0.786f)   // one short tap
            expLane = (car + dir).coerceIn(0, 2); settleUntil = now + 230
        }
    }

    /** سرعة تقدم العوائق على الشاشة (جزء من الارتفاع/ثانية) من تغير موضع أقرب عائق بين إطارين. */
    private fun updateSpeed(r: Vision.Result, now: Long) {
        val dt = (now - prevT) / 1000f
        if (prevT > 0 && dt > 0f) for (l in 0..2) {
            val d = r.haz[l] - prevHaz[l]
            if (prevHaz[l] >= 0f && r.haz[l] >= 0f && d > 0.002f && d < 0.2f)
                speed = (0.8f * speed + 0.2f * (d / dt)).coerceIn(0.05f, 2f)
        }
        for (l in 0..2) prevHaz[l] = r.haz[l]
        prevT = now
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, BotService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "bot").setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(getString(R.string.notif_running))
            .addAction(Notification.Action.Builder(null, getString(R.string.btn_stop), stop).build()).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        running = false
        vd?.release(); reader?.close(); projection?.stop(); thread?.quitSafely(); injector.close()
        super.onDestroy()
    }
}
