package com.example.speedbot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var auto: Switch
    private val ui = Handler(Looper.getMainLooper())

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val ticker = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 1500) }
    }

    override fun attachBaseContext(newBase: Context) { super.attachBaseContext(Lang.wrap(newBase)) }

    private fun c(hex: String) = Color.parseColor(hex)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(c("#14FFFFFF"), 22, c("#26FFFFFF"))
        setPadding(dp(18), dp(16), dp(18), dp(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
    }

    private fun button(label: String, bg: GradientDrawable, color: Int, onClick: () -> Unit) =
        Button(this).apply {
            this.text = label
            setTextColor(color)
            isAllCaps = false
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = bg
            stateListAnimator = null
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            setOnClickListener { onClick() }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cyan = c("#00E5FF")
        window.statusBarColor = c("#070B1E")
        window.navigationBarColor = c("#1A1040")

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }

        // language switch
        val isAr = resources.configuration.locales[0].language == "ar"
        val langBtn = TextView(this).apply {
            text = getString(R.string.lang_switch)
            setTextColor(cyan)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            background = shape(c("#1400E5FF"), 20, c("#5500E5FF"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener {
                Lang.set(this@MainActivity, if (isAr) "en" else "ar")
                recreate()
            }
        }
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.END
            addView(langBtn)
        })

        // logo + title
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(c("#0B1026"), c("#5A1A6B"))
            ).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), cyan) }
            layoutParams = LinearLayout.LayoutParams(dp(128), dp(128)).apply {
                gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8)
            }
        }
        col.addView(logo)

        val title = TextView(this).apply {
            val s = SpannableString(getString(R.string.app_name))
            s.setSpan(ForegroundColorSpan(cyan), 0, minOf(3, s.length), 0)
            text = s
            setTextColor(Color.WHITE)
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        }
        col.addView(title)
        col.addView(TextView(this).apply {
            text = getString(R.string.tagline)
            setTextColor(c("#9AA4D6"))
            textSize = 14f
            gravity = Gravity.CENTER
        })

        // status card
        statusDot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(12) }
        }
        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        col.addView(card().apply {
            val row = LinearLayout(this@MainActivity).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(statusDot); addView(statusText)
            }
            addView(row)
        })

        // features card
        col.addView(card().apply {
            for (res in intArrayOf(R.string.feat_fuel, R.string.feat_dodge, R.string.feat_maps)) {
                addView(TextView(this@MainActivity).apply {
                    text = getString(res)
                    setTextColor(c("#D7DCFF"))
                    textSize = 15f
                    setPadding(0, dp(4), 0, dp(4))
                })
            }
        })

        // controls card
        auto = Switch(this).apply {
            text = getString(R.string.auto_retry)
            setTextColor(c("#D7DCFF"))
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }
        }
        col.addView(card().apply {
            addView(auto)
            addView(button(getString(R.string.btn_perm), shape(c("#1000E5FF"), 16, cyan), cyan) {
                if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                    Shizuku.requestPermission(1) else refresh()
            })
            addView(button(
                getString(R.string.btn_start),
                GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(c("#00E676"), c("#00E5FF"))
                ).apply { cornerRadius = dp(16).toFloat() },
                c("#04121F")
            ) {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), 42)
            })
            addView(button(getString(R.string.btn_stop), shape(c("#18FF3D81"), 16, c("#FF3D81")), c("#FF6B9D")) {
                startService(Intent(this@MainActivity, BotService::class.java).setAction("STOP"))
                ui.postDelayed({ refresh() }, 400)
            })
        })

        col.addView(TextView(this).apply {
            text = getString(R.string.footer)
            setTextColor(c("#6B74A8"))
            textSize = 12f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
        })

        setContentView(ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(c("#070B1E"), c("#1A1040"), c("#2B0F3A"))
            )
            isFillViewport = true
            addView(col)
        })

        Shizuku.addRequestPermissionResultListener(permListener)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        refresh()
    }

    private fun refresh() {
        val (msg, color) = when {
            BotService.running -> getString(R.string.status_running) to "#00E676"
            !Shizuku.pingBinder() -> getString(R.string.status_no_shizuku) to "#FF3D81"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                getString(R.string.status_no_perm) to "#FFC400"
            else -> getString(R.string.status_ready) to "#00E676"
        }
        statusText.text = msg
        statusDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(color))
        }
    }

    override fun onResume() { super.onResume(); ui.post(ticker) }
    override fun onPause() { ui.removeCallbacks(ticker); super.onPause() }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 42 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, BotService::class.java)
                    .putExtra("code", res).putExtra("data", data).putExtra("auto", auto.isChecked)
            )
            ui.postDelayed({ refresh() }, 600)
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }
}
