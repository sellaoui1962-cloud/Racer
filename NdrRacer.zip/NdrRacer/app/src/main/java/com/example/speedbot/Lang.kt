package com.example.speedbot

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** In-app language switch (English / Arabic). Empty = follow the phone language. */
object Lang {
    private const val PREFS = "ndr_prefs"
    private const val KEY = "lang"

    fun get(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""

    fun set(ctx: Context, lang: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, lang).apply()
    }

    fun wrap(base: Context): Context {
        val l = get(base)
        if (l.isEmpty()) return base
        val loc = Locale(l)
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        return base.createConfigurationContext(cfg)
    }
}
