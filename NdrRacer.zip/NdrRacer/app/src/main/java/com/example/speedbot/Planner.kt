package com.example.speedbot

import kotlin.math.abs

/**
 * Decides: -1 left, +1 right, 0 stay.
 * Safety first: never enter a lane whose obstacle would reach the car before the lane change
 * is finished (time based, using the measured road speed). In flag races one hit ends the race,
 * so the safety margins are larger. Pickups are only chased when they are reached before any
 * obstacle of that lane. Priority: fuel > rocket > flag / other bubbles > coins.
 * speed = fraction of the screen height per second.
 */
object Planner {
    private const val CAR_TOP = 0.535f

    private fun clear(y: Float, limit: Float) = y < 0f || y < limit

    fun decide(r: Vision.Result, car: Int, speed: Float, fuelMode: Boolean): Int {
        if (car < 0) return 0
        val haz = r.haz
        val v = speed.coerceIn(0.10f, 0.80f)
        val tChange = if (fuelMode) 0.34f else 0.45f     // seconds needed to change lane + reaction
        val margin = if (fuelMode) 0.04f else 0.07f
        val enterY = (CAR_TOP - v * tChange - margin).coerceIn(0.10f, 0.50f)
        val dangerY = (CAR_TOP - v * (tChange + 0.30f) - margin).coerceIn(0.05f, 0.45f)

        var best = car; var bestScore = score(car, car, r, dangerY, fuelMode)
        for (t in 0..2) {
            if (t == car) continue
            val step = if (t > car) 1 else -1
            var ok = true; var l = car + step
            while (true) { if (!clear(haz[l], enterY)) ok = false; if (l == t) break; l += step }
            if (!ok) continue
            val s = score(t, car, r, dangerY, fuelMode)
            if (s > bestScore + 0.15f) { best = t; bestScore = s }
        }
        return Integer.signum(best - car)
    }

    private fun score(l: Int, c: Int, r: Vision.Result, dangerY: Float, fuelMode: Boolean): Float {
        val h = r.haz[l]
        var s = if (h < 0f) 1.2f else 1f - h
        if (h >= 0f && h > dangerY) s -= 1.0f
        if (l == 1) s += 0.05f                       // centre lane keeps two escape routes
        // a pickup is worth a detour only when we reach it before any obstacle in that lane
        val gap = if (fuelMode) 0.06f else 0.12f
        fun ok(y: Float) = y >= 0f && (h < 0f || y > h + gap)
        if (ok(r.fuel[l])) s += if (fuelMode) 1.2f else 1.0f
        if (ok(r.rocket[l])) s += if (fuelMode) 0.9f else 0.6f
        if (ok(r.bub[l])) s += if (fuelMode) 0.6f else 0.7f
        if (ok(r.coin[l])) s += if (fuelMode) 0.4f else 0.15f
        s -= 0.1f * abs(l - c)
        return s
    }
}
