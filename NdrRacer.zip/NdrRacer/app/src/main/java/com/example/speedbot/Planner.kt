package com.example.speedbot

import kotlin.math.abs

/**
 * Decides: -1 left, +1 right, 0 stay.
 * Rules: never enter a lane with an obstacle close to the car; prefer lanes that are free;
 * go for pickups when the lane is safe (fuel > bubbles > coins). Thresholds adapt to the road speed
 * (speed = fraction of screen height per second).
 */
object Planner {
    private const val CAR_TOP = 0.535f

    private fun clear(y: Float, limit: Float) = y < 0f || y < limit

    fun decide(r: Vision.Result, car: Int, speed: Float): Int {
        if (car < 0) return 0
        val haz = r.haz
        // the faster the road, the earlier we escape (lane change takes ~0.25 s + capture delay)
        val dangerY = (CAR_TOP - (0.10f + 0.5f * speed)).coerceIn(0.12f, 0.40f)
        val enterY = (CAR_TOP - speed * 0.30f - 0.04f).coerceIn(0.25f, 0.50f)

        var best = car; var bestScore = score(car, car, r, dangerY)
        for (t in 0..2) {
            if (t == car) continue
            val step = if (t > car) 1 else -1
            var ok = true; var l = car + step
            while (true) { if (!clear(haz[l], enterY)) ok = false; if (l == t) break; l += step }
            if (!ok) continue
            val s = score(t, car, r, dangerY)
            if (s > bestScore + 0.15f) { best = t; bestScore = s }
        }
        return Integer.signum(best - car)
    }

    private fun score(l: Int, c: Int, r: Vision.Result, dangerY: Float): Float {
        val h = r.haz[l]
        var s = if (h < 0f) 1.2f else 1f - h
        if (h >= 0f && h > dangerY) s -= 1.0f
        // a pickup is worth a detour only when we reach it before any obstacle in that lane
        val f = r.fuel[l]; val b = r.bub[l]; val k = r.coin[l]
        if (f >= 0f && (h < 0f || f > h + 0.06f)) s += 1.0f
        if (b >= 0f && (h < 0f || b > h + 0.06f)) s += 0.7f
        if (k >= 0f && (h < 0f || k > h + 0.06f)) s += 0.5f
        s -= 0.1f * abs(l - c)
        return s
    }
}
