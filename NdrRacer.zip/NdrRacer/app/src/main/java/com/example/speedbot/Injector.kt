package com.example.speedbot

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.OutputStream

/**
 * نقرة واحدة سريعة (DOWN ثم UP بعد ~10ms — ليست ضغطاً مطولاً).
 * المسار السريع: حقن مباشر عبر InputManager بصلاحية shell من Shizuku (بضع ms).
 * احتياطي: `input tap` عبر شل دائم (أبطأ ~100ms+).
 */
class Injector {
    private var im: Any? = null
    private var inject: java.lang.reflect.Method? = null
    private var triedFast = false

    private var proc: Process? = null
    private var out: OutputStream? = null

    private fun initFast() {
        if (triedFast) return
        triedFast = true
        try {
            HiddenApiBypass.addHiddenApiExemptions("L")
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            inject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (e: Throwable) { android.util.Log.e("Injector", "fast path failed", e); im = null }
    }

    fun tap(x: Int, y: Int) {
        initFast()
        if (im != null && fastTap(x, y)) return
        shellTap(x, y)
    }

    private fun fastTap(x: Int, y: Int): Boolean = try {
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x.toFloat(), y.toFloat(), 0)
        down.source = InputDevice.SOURCE_TOUCHSCREEN
        inject!!.invoke(im, down, 0)   // 0 = ASYNC
        down.recycle()
        val up = MotionEvent.obtain(t, t + 10, MotionEvent.ACTION_UP, x.toFloat(), y.toFloat(), 0)
        up.source = InputDevice.SOURCE_TOUCHSCREEN
        inject!!.invoke(im, up, 0)
        up.recycle()
        true
    } catch (e: Throwable) { android.util.Log.e("Injector", "inject", e); im = null; false }

    @Synchronized
    private fun shellTap(x: Int, y: Int) {
        try {
            if (proc?.isAlive != true) {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                m.isAccessible = true
                proc = m.invoke(null, arrayOf("sh"), null, null) as Process
                out = proc!!.outputStream
            }
            out!!.write("input tap $x $y\n".toByteArray()); out!!.flush()
        } catch (e: Throwable) { android.util.Log.e("Injector", "shell", e); proc = null }
    }

    fun close() { try { proc?.destroy() } catch (_: Throwable) {}; proc = null }
}
