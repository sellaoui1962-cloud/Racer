package com.example.speedbot

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Frame analysis that does NOT depend on the track colour (desert, asphalt, anything else).
 *
 * Idea: the road scrolls vertically, so every pixel column has (almost) the same background colour
 * from top to bottom. The per-column median colour is therefore the background (lane lines and
 * shoulders included). Anything that differs from it is an object. Objects are then classified:
 *   - fuel     : a red jerry can inside a glass bubble          -> collected first
 *   - bonus    : coin trails and other bubbles (flag, magnet, rings) -> collected
 *   - ignored  : countdown digits, shield glow, sparks
 *   - hazard   : everything else (cactus, stump, barrier, tyres, containers, cones...) -> dodged
 * All values are fractions of the screen so any resolution works.
 */
object Vision {
    const val ROAD_L = 0.127f
    const val ROAD_R = 0.875f
    const val LOOK_TOP = 0.10f
    const val LOOK_BOTTOM = 0.725f
    const val HUD_Y = 0.30f
    const val HUD_X = 0.64f
    private const val FG_THR = 38          // colour distance from the column background = object
    private const val BG_FALLBACK = 45     // column background too far from the global one -> use global

    class Result(
        val racing: Boolean,       // a race is on screen (not a menu / result screen)
        val car: Int,              // lane of the car 0..2 or -1
        val carX: Float,           // car centre as a fraction of the width, or -1
        val haz: FloatArray,       // lowest edge (fraction of height) of the nearest hazard per lane, or -1
        val fuel: FloatArray,      // lowest edge of the nearest fuel bubble per lane, or -1
        val coin: FloatArray,      // lowest edge of the nearest coin trail per lane, or -1
        val bub: FloatArray,       // lowest edge of the nearest other bubble (flag, magnet, rings...) per lane, or -1
        val menu: Boolean          // the orange "challenge" button is visible
    )

    private var cap = 0
    private var mask = BooleanArray(0)
    private var tmp = BooleanArray(0)
    private var dil = BooleanArray(0)
    private var seen = BooleanArray(0)
    private var stack = IntArray(0)

    private fun ensure(n: Int) {
        if (cap == n) return
        cap = n
        mask = BooleanArray(n); tmp = BooleanArray(n); dil = BooleanArray(n)
        seen = BooleanArray(n); stack = IntArray(n)
    }

    private fun r(p: Int) = p shr 16 and 255
    private fun g(p: Int) = p shr 8 and 255
    private fun b(p: Int) = p and 255

    /** hintX: expected car position (fraction of width) used when the car is not visible, or -1. */
    fun analyze(px: IntArray, w: Int, h: Int, hintX: Float): Result {
        ensure(w * h)
        java.util.Arrays.fill(mask, false); java.util.Arrays.fill(tmp, false)
        java.util.Arrays.fill(dil, false); java.util.Arrays.fill(seen, false)

        val x0 = (ROAD_L * w).toInt(); val x1 = (ROAD_R * w).toInt()
        val yT = (LOOK_TOP * h).toInt(); val yB = (LOOK_BOTTOM * h).toInt()
        val cols = x1 - x0

        // ---- car (red stripes, tall narrow group) ----
        val det = detectCar(px, w, h)
        val carX = if (det >= 0f) det else hintX
        val carPx = carX * w
        val car = if (det >= 0f) (((det - ROAD_L) / (ROAD_R - ROAD_L)) * 3).toInt().coerceIn(0, 2) else -1

        // ---- background colour per column (median) ----
        val bgR = IntArray(cols); val bgG = IntArray(cols); val bgB = IntArray(cols)
        val hist = IntArray(256)
        val rows = yB - yT
        val half = (rows + 1) / 2
        for (ch in 0..2) {
            val shift = 16 - 8 * ch
            val out = when (ch) { 0 -> bgR; 1 -> bgG; else -> bgB }
            for (xi in 0 until cols) {
                java.util.Arrays.fill(hist, 0)
                val x = x0 + xi
                for (y in yT until yB) hist[(px[y * w + x] shr shift) and 255]++
                var acc = 0; var m = 0
                while (m < 255) { acc += hist[m]; if (acc >= half) break; m++ }
                out[xi] = m
            }
        }
        // global median as a fallback for columns that are mostly covered by an object (e.g. coin trails)
        val gh0 = IntArray(256); val gh1 = IntArray(256); val gh2 = IntArray(256)
        var gn = 0
        var gy = yT
        while (gy < yB) {
            var gx = x0
            while (gx < x1) {
                val p = px[gy * w + gx]
                gh0[r(p)]++; gh1[g(p)]++; gh2[b(p)]++; gn++
                gx += 2
            }
            gy += 2
        }
        val gHalf = (gn + 1) / 2
        val gR = median(gh0, gHalf); val gG = median(gh1, gHalf); val gB = median(gh2, gHalf)
        for (xi in 0 until cols) {
            if (max(abs(bgR[xi] - gR), max(abs(bgG[xi] - gG), abs(bgB[xi] - gB))) > BG_FALLBACK) {
                bgR[xi] = gR; bgG[xi] = gG; bgB[xi] = gB
            }
        }

        // ---- foreground mask ----
        val hudY = (HUD_Y * h).toInt(); val hudX = (HUD_X * w).toInt()
        val zx0 = if (carX >= 0f) (carPx - 0.095f * w).toInt() else 0
        val zx1 = if (carX >= 0f) (carPx + 0.095f * w).toInt() else -1
        val zy0 = (0.52f * h).toInt(); val zy1 = (0.73f * h).toInt()
        var bgCnt = 0; var tot = 0
        for (y in yT until yB) {
            val row = y * w
            for (xi in 0 until cols) {
                val x = x0 + xi
                val p = px[row + x]
                val d = max(abs(r(p) - bgR[xi]), max(abs(g(p) - bgG[xi]), abs(b(p) - bgB[xi])))
                tot++
                if (d <= FG_THR) { bgCnt++; continue }
                if (y < hudY && x > hudX) continue                       // distance / score panel
                if (y >= zy0 && y < zy1 && x >= zx0 && x < zx1) continue // the car itself
                mask[row + x] = true
            }
        }
        // a race has an almost uniform road; menus / result screens do not
        val racing = tot > 0 && bgCnt.toFloat() / tot >= 0.70f
        if (!racing) {
            return Result(false, -1, -1f, FloatArray(3) { -1f }, FloatArray(3) { -1f }, FloatArray(3) { -1f }, FloatArray(3) { -1f }, detectMenu(px, w, h))
        }

        // blue shield glow around the car is not an obstacle
        var glow = 0
        if (carX >= 0f) {
            val gx0 = max(x0, (carPx - 0.32f * w).toInt()); val gx1 = min(x1, (carPx + 0.32f * w).toInt())
            val gy0 = max(yT, (0.40f * h).toInt()); val gy1 = min(yB, (0.72f * h).toInt())
            for (y in gy0 until gy1) for (x in gx0 until gx1) {
                val p = px[y * w + x]
                if (b(p) > r(p) + 40 && b(p) > 120) {
                    glow++
                    for (dy in -2..2) for (dx in -2..2) {
                        val ty = y + dy; val tx = x + dx
                        if (ty >= yT && ty < yB && tx >= x0 && tx < x1) mask[ty * w + tx] = false
                    }
                }
            }
        }
        val shield = glow >= 100

        // ---- 5x5 dilation to join the parts of one object ----
        for (y in yT until yB) {
            val row = y * w
            for (x in x0 until x1) {
                var v = false
                var dx = -2
                while (dx <= 2) {
                    val xx = x + dx
                    if (xx >= x0 && xx < x1 && mask[row + xx]) { v = true; break }
                    dx++
                }
                tmp[row + x] = v
            }
        }
        for (y in yT until yB) {
            for (x in x0 until x1) {
                var v = false
                var dy = -2
                while (dy <= 2) {
                    val yy = y + dy
                    if (yy >= yT && yy < yB && tmp[yy * w + x]) { v = true; break }
                    dy++
                }
                dil[y * w + x] = v
            }
        }

        // ---- connected components and classification ----
        val haz = FloatArray(3) { -1f }; val fuel = FloatArray(3) { -1f }
        val coinL = FloatArray(3) { -1f }; val bubL = FloatArray(3) { -1f }
        val roadW = (ROAD_R - ROAD_L) * w
        val laneW = roadW / 3f
        val roadX0 = ROAD_L * w
        for (sy in yT until yB) for (sx in x0 until x1) {
            val start = sy * w + sx
            if (!dil[start] || seen[start]) continue
            var sp = 0; stack[sp++] = start; seen[start] = true
            var minX = w; var maxX = 0; var minY = h; var maxY = 0
            var cnt = 0; var coin = 0; var white = 0; var blue = 0; var spark = 0; var sumMx = 0L
            while (sp > 0) {
                val i = stack[--sp]; val qy = i / w; val qx = i % w
                if (qx < minX) minX = qx
                if (qx > maxX) maxX = qx
                if (qy < minY) minY = qy
                if (qy > maxY) maxY = qy
                if (mask[i]) {
                    cnt++
                    val p = px[i]; val rr = r(p); val gg = g(p); val bb = b(p)
                    val mx = max(rr, max(gg, bb)); val mn = min(rr, min(gg, bb))
                    sumMx += mx
                    if (rr > 180 && gg > 140 && bb < 110) coin++
                    if (rr > 200 && gg > 120 && bb < 100) spark++
                    if (mn > 170 && mx - mn < 40) white++
                    if (bb > rr + 40 && bb > 120) blue++
                }
                if (qx > 0 && dil[i - 1] && !seen[i - 1]) { seen[i - 1] = true; stack[sp++] = i - 1 }
                if (qx < w - 1 && dil[i + 1] && !seen[i + 1]) { seen[i + 1] = true; stack[sp++] = i + 1 }
                if (qy > 0 && dil[i - w] && !seen[i - w]) { seen[i - w] = true; stack[sp++] = i - w }
                if (qy < h - 1 && dil[i + w] && !seen[i + w]) { seen[i + w] = true; stack[sp++] = i + w }
            }
            if (cnt < 25) continue
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            if (bw > 0.6f * roadW) continue                                   // full-width banner
            if (coin.toFloat() / cnt > 0.5f) {                                // gold coins: collect
                if (minY.toFloat() / h < 0.60f) {
                    val ln = (((minX + bw / 2f) - roadX0) / laneW).toInt().coerceIn(0, 2)
                    val yb = (maxY + 1).toFloat() / h
                    if (yb > coinL[ln]) coinL[ln] = yb
                }
                continue
            }
            if (blue.toFloat() / cnt > 0.30f) continue                        // countdown digit / shield glow
            if ((cnt < 60 && sumMx.toFloat() / cnt > 200f) ||
                (cnt < 150 && spark.toFloat() / cnt > 0.25f)) continue        // sparks
            val cxm = minX + bw / 2f; val cym = minY + bh / 2f
            val yTopF = minY.toFloat() / h; val yBotF = (maxY + 1).toFloat() / h
            if (shield && carX >= 0f && abs(cxm - carPx) < 0.40f * w &&
                cym >= 0.35f * h && cym <= 0.85f * h) continue               // inside the shield

            // glass bubble: roughly square, round rim, some white
            val sq = bw >= 0.13f * w && bw <= 0.30f * w && bh >= 0.13f * w && bh <= 0.30f * w &&
                bw.toFloat() / bh >= 0.75f && bw.toFloat() / bh <= 1.33f
            if (sq && white.toFloat() / cnt >= 0.02f) {
                val rad = min(bw, bh) / 2f - 1.5f
                if (ringCover(mask, w, h, cxm, cym, rad) >= 0.70f) {
                    if (yTopF < 0.58f) {
                        val ln = ((cxm - roadX0) / laneW).toInt().coerceIn(0, 2)
                        if (isFuel(px, w, h, cxm, cym, rad)) { if (yBotF > fuel[ln]) fuel[ln] = yBotF }
                        else if (yBotF > bubL[ln]) bubL[ln] = yBotF
                    }
                    continue   // bubbles are never obstacles
                }
            }

            // everything else is an obstacle: it blocks every lane whose corridor it overlaps
            if (yTopF < 0.68f) {
                for (l in 0..2) {
                    val c = roadX0 + laneW * (l + 0.5f)
                    if (minX <= c + 0.11f * w && maxX + 1 >= c - 0.11f * w) {
                        if (yBotF > haz[l]) haz[l] = yBotF
                    }
                }
            }
        }
        return Result(true, car, if (det >= 0f) det else -1f, haz, fuel, coinL, bubL, false)
    }

    private fun median(hh: IntArray, half: Int): Int {
        var acc = 0
        for (m in 0..255) { acc += hh[m]; if (acc >= half) return m }
        return 255
    }

    /** Red stripes of the car: densest 17%-wide window in the lower half that is tall enough. */
    private fun detectCar(px: IntArray, w: Int, h: Int): Float {
        val y0 = (0.5f * h).toInt(); val y1 = (0.8f * h).toInt()
        val col = IntArray(w)
        for (y in y0 until y1) for (x in 0 until w) {
            val p = px[y * w + x]
            if (r(p) > 150 && g(p) < 70 && b(p) < 70) col[x]++
        }
        val win = (0.17f * w).toInt()
        if (win < 1 || win >= w) return -1f
        var run = 0
        for (x in 0 until win) run += col[x]
        var best = run; var bx = 0
        for (x in 1..(w - win)) {
            run += col[x + win - 1] - col[x - 1]
            if (run > best) { best = run; bx = x }
        }
        if (best < 60) return -1f
        var minY = h; var maxY = 0; var sx = 0L; var n = 0
        for (y in y0 until y1) for (x in bx until bx + win) {
            val p = px[y * w + x]
            if (r(p) > 150 && g(p) < 70 && b(p) < 70) {
                n++; sx += x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (n == 0 || maxY - minY + 1 < 0.09f * h) return -1f
        return sx.toFloat() / n / w
    }

    /** Fraction of ring points (radius rad-2..rad+1) that belong to the foreground mask. */
    private fun ringCover(m: BooleanArray, w: Int, h: Int, cx: Float, cy: Float, rad: Float): Float {
        var ok = 0
        for (a in 0 until 32) {
            val t = a * 2.0 * Math.PI / 32
            var hit = false
            var rr = rad - 2f
            while (rr <= rad + 1f) {
                val x = Math.round(cx + rr * cos(t)).toInt(); val y = Math.round(cy + rr * sin(t)).toInt()
                if (x >= 0 && x < w && y >= 0 && y < h && m[y * w + x]) { hit = true; break }
                rr += 1f
            }
            if (hit) ok++
        }
        return ok / 32f
    }

    /** A bubble holds fuel when its inside is clearly red/orange and not blue (magnet / rings). */
    private fun isFuel(px: IntArray, w: Int, h: Int, cx: Float, cy: Float, rad: Float): Boolean {
        val rr = rad * 0.85f
        val xa = max(0, (cx - rr).toInt() - 1); val xb = min(w - 1, (cx + rr).toInt() + 1)
        val ya = max(0, (cy - rr).toInt() - 1); val yb = min(h - 1, (cy + rr).toInt() + 1)
        var n = 0; var red = 0; var blue = 0
        for (y in ya..yb) for (x in xa..xb) {
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy > rr * rr) continue
            n++
            val p = px[y * w + x]; val rv = r(p); val gv = g(p); val bv = b(p)
            if (rv > 150 && gv < 95 && bv < 95) red++
            if (bv > rv + 25 && bv > 120) blue++
        }
        return n > 0 && red.toFloat() / n >= 0.12f && blue.toFloat() / n < 0.06f
    }

    /** Orange "challenge" button of the results / lobby screen. */
    private fun detectMenu(px: IntArray, w: Int, h: Int): Boolean {
        var btn = 0; var bt = 0
        for (y in (0.77f * h).toInt() until (0.83f * h).toInt()) for (x in (0.35f * w).toInt() until (0.65f * w).toInt()) {
            val p = px[y * w + x]
            if (r(p) > 200 && g(p) in 111..199 && b(p) < 90) btn++
            bt++
        }
        return bt > 0 && btn.toFloat() / bt > 0.3f
    }
}
